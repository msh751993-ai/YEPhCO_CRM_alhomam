# YEPHCO CRM APK

هذا المشروع يغلف نسخة PWA من YEPHCO داخل تطبيق Android WebView.

## البناء من GitHub
1. ارفع جميع الملفات إلى مستودع GitHub جديد.
2. افتح Actions.
3. اختر Build YEPHCO APK.
4. اضغط Run workflow إذا لم يبدأ تلقائياً.
5. بعد اكتمال البناء افتح نتيجة التشغيل ثم قسم Artifacts وحمّل YEPhCO-CRM-APK.
